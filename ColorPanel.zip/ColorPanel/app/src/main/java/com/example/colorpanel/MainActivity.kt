package com.example.colorpanel

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private val bars = HashMap<String, SeekBar>()
    private val labels = HashMap<String, TextView>()

    private class Spec(val key: String, val title: String, val min: Float, val max: Float, val step: Float, val def: Float)
    private val specs = listOf(
        Spec("hue", "Hue (°)", -180f, 180f, 1f, 0f),
        Spec("sat", "Vibrance / Saturasi", 0f, 3f, 0.01f, 1f),
        Spec("bri", "Kecerahan", 0.5f, 1.5f, 0.01f, 1f),
        Spec("con", "Kontras", 0.5f, 1.5f, 0.01f, 1f)
    )

    private fun v(key: String): Float {
        val s = specs.first { it.key == key }
        return s.min + bars[key]!!.progress * s.step
    }

    private fun setV(key: String, value: Float) {
        val s = specs.first { it.key == key }
        bars[key]!!.progress = ((value - s.min) / s.step).toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("panel", MODE_PRIVATE)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (40 * dp).toInt(), (20 * dp).toInt(), (20 * dp).toInt())
        }
        root.addView(TextView(this).apply { text = "Color Panel"; textSize = 26f; setTextColor(Color.WHITE) })
        status = TextView(this).apply { textSize = 13f; setTextColor(Color.LTGRAY) }
        root.addView(status)

        for (s in specs) {
            val label = TextView(this).apply { setTextColor(Color.WHITE); setPadding(0, (18 * dp).toInt(), 0, 0) }
            val bar = SeekBar(this)
            bar.max = ((s.max - s.min) / s.step).toInt()
            bar.progress = ((prefs.getFloat(s.key, s.def) - s.min) / s.step).toInt()
            bars[s.key] = bar; labels[s.key] = label
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    refreshLabels()
                    if (fromUser) scheduleApply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            root.addView(label); root.addView(bar)
        }
        refreshLabels()

        fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text; isAllCaps = false; setOnClickListener { onClick() }
        }
        val presetRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        presetRow.addView(btn("Normal") { preset(0f, 1f, 1f, 1f) })
        presetRow.addView(btn("Vivid") { preset(0f, 1.4f, 1.02f, 1.05f) })
        presetRow.addView(btn("Ultra") { preset(0f, 1.9f, 1.05f, 1.1f) })
        root.addView(presetRow)

        root.addView(btn("Hubungkan Shizuku") { requestShizuku() })
        root.addView(btn("Terapkan") { applyNow() })
        root.addView(btn("Reset") { preset(0f, 1f, 1f, 1f); runCmd(ColorMath.RESET) })
        root.addView(btn("Salin perintah ADB") {
            val cmd = "adb shell \"" + ColorMath.command(v("hue"), v("sat"), v("bri"), v("con")) + "\""
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("adb", cmd))
            Toast.makeText(this, "Perintah ADB disalin", Toast.LENGTH_SHORT).show()
        })

        setContentView(ScrollView(this).apply { addView(root) })
        updateStatus()
    }

    private fun refreshLabels() {
        for (s in specs) labels[s.key]!!.text = "${s.title}: " + String.format("%.2f", v(s.key))
    }

    private fun preset(h: Float, s: Float, b: Float, c: Float) {
        setV("hue", h); setV("sat", s); setV("bri", b); setV("con", c)
        refreshLabels(); applyNow()
    }

    private val applyTask = Runnable { applyNow() }
    private fun scheduleApply() { ui.removeCallbacks(applyTask); ui.postDelayed(applyTask, 80) }

    private fun applyNow() {
        val e = prefs.edit()
        for (s in specs) e.putFloat(s.key, v(s.key))
        e.apply()
        runCmd(ColorMath.command(v("hue"), v("sat"), v("bri"), v("con")))
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Shizuku belum berjalan. Buka aplikasi Shizuku dan start dulu.", Toast.LENGTH_LONG).show()
            } else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(1)
            }
        } catch (e: Throwable) {
            Toast.makeText(this, "Shizuku tidak ditemukan", Toast.LENGTH_LONG).show()
        }
        ui.postDelayed({ updateStatus() }, 1500)
    }

    private fun updateStatus() {
        status.text = if (shizukuReady()) "Shizuku: terhubung ✔" else "Shizuku: belum terhubung (atau pakai tombol Salin perintah ADB)"
    }

    private fun runCmd(cmd: String) {
        if (!shizukuReady()) { updateStatus(); return }
        worker.execute {
            val ok = try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
                p.waitFor() == 0
            } catch (e: Throwable) { false }
            if (!ok) ui.post { Toast.makeText(this, "Gagal menerapkan (HP mungkin tidak mendukung)", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onResume() { super.onResume(); updateStatus() }
}
