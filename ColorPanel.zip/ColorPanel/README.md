# Color Panel (Android)
Cara build APK:
1. Android Studio: File > Open folder ini > Build > Build APK(s)
2. Atau upload ke GitHub, tab Actions > Build APK > unduh artifact.

Cara pakai:
1. Install Shizuku dari Play Store lalu start (Wireless debugging).
2. Buka Color Panel > Hubungkan Shizuku > izinkan.
3. Geser slider Hue / Vibrance / Kecerahan / Kontras.
Efek hilang saat HP restart; buka aplikasi lalu tekan Terapkan lagi.
