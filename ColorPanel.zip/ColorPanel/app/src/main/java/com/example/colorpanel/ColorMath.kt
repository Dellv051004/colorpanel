package com.example.colorpanel

import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object ColorMath {
    private fun mul(a: FloatArray, b: FloatArray): FloatArray { // row-major 4x4
        val o = FloatArray(16)
        for (r in 0..3) for (c in 0..3) {
            var s = 0f
            for (k in 0..3) s += a[r * 4 + k] * b[k * 4 + c]
            o[r * 4 + c] = s
        }
        return o
    }

    private fun identity() = floatArrayOf(1f,0f,0f,0f, 0f,1f,0f,0f, 0f,0f,1f,0f, 0f,0f,0f,1f)

    private fun hueM(deg: Float): FloatArray {
        val a = deg * PI.toFloat() / 180f
        val c = cos(a); val s = sin(a)
        return floatArrayOf(
            0.213f + c*0.787f - s*0.213f, 0.715f - c*0.715f - s*0.715f, 0.072f - c*0.072f + s*0.928f, 0f,
            0.213f - c*0.213f + s*0.143f, 0.715f + c*0.285f + s*0.140f, 0.072f - c*0.072f - s*0.283f, 0f,
            0.213f - c*0.213f - s*0.787f, 0.715f - c*0.715f + s*0.715f, 0.072f + c*0.928f + s*0.072f, 0f,
            0f, 0f, 0f, 1f)
    }

    private fun satM(s: Float): FloatArray {
        val lr = 0.2126f; val lg = 0.7152f; val lb = 0.0722f
        val i = 1f - s
        return floatArrayOf(
            lr*i + s, lg*i, lb*i, 0f,
            lr*i, lg*i + s, lb*i, 0f,
            lr*i, lg*i, lb*i + s, 0f,
            0f, 0f, 0f, 1f)
    }

    private fun briConM(bri: Float, con: Float): FloatArray {
        val g = bri * con
        val t = bri * 0.5f * (1f - con)
        return floatArrayOf(
            g,0f,0f,t, 0f,g,0f,t, 0f,0f,g,t, 0f,0f,0f,1f)
    }

    /** Perintah shell untuk SurfaceFlinger (matriks dikirim column-major). */
    fun command(hue: Float, sat: Float, bri: Float, con: Float): String {
        val m = mul(briConM(bri, con), mul(satM(sat), hueM(hue)))
        val sb = StringBuilder("service call SurfaceFlinger 1015 i32 1")
        for (c in 0..3) for (r in 0..3)
            sb.append(" f ").append(String.format(Locale.US, "%.5f", m[r * 4 + c]))
        return sb.toString()
    }

    const val RESET = "service call SurfaceFlinger 1015 i32 0"
}
